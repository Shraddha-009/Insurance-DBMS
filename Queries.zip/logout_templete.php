<form action="logout.php" method="POST">
	<table>
		<tr>
			<td><input type="submit" value="Logout"/></td>
		</tr>
	</table>
	</form>